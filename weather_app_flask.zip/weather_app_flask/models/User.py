class User:
    __id = None
    __name = None
    __email = None
    __username = None
    __password = None
    __description = None

    def __init__(self):
        pass

    def setId(self , id):
        self.__id = id

    def getId(self):
        return self.__id

    def setName(self, name):
        self.__name = name

    def getName(self):
        return self.__name

    def setUsername(self, username):
        self.__username = username

    def getUsername(self):
        return self.__username    

    def setEmail(self, email):
        self.__email = email

    def getEmail(self):
        return self.__email

    def setPassword(self, password):
        self.__password = password

    def getPassword(self):
        return self.__password

    def setDescription(self, description):
        self.__description = description

    def getDescription(self):
        return self.__description    
