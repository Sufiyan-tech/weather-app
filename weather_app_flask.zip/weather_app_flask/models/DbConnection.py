import mysql.connector

class DbConnection:
    __conn = None 

    def __init__(self):
        try:
            self.__conn = mysql.connector.connect(host="localhost" , user="root" , passwd="" , database="weather_app")
        except Exception as e:
            print(e)    

    def getConn(self):
        return self.__conn        