class Forecast:
    __id = None 
    __temp = None 
    __pressure = None 
    __humidity = None 
    __main = None 
    __description = None
    __location = None

    def __init__(self):
        pass 

    def setId(self , id):
        self.__id = id     

    def getId(self):
        return self.__id

    def setTemp(self , temp):
        self.__temp = temp 

    def getTemp(self):
        return self.__temp 

    def setPressure(self , pressure):
        self.__pressure =  pressure

    def getPressure(self):
        return self.__pressure

    def setHumidity(self , humidity):
        self.__humidity =  humidity

    def getHumidity(self):
        return self.__humidity

    def setMain(self , main):
        self.__main =  main

    def getMain(self):
        return self.__main                    

    def setDescription(self, description):
        self.__description = description

    def getDescription(self):
        return self.__description    

    def setLocation(self, location):
        self.__location = location

    def getLocation(self):
        return self.__location    
