from models.DbConnection import DbConnection
from models.User import User
import mysql.connector


class UserModel:
    __conn = None 
    __curr = None 

    def __init__(self):
        try:
            self.__conn = DbConnection().getConn()
            self.__curr = self.__conn.cursor()
        except:
            print("Some Unexpected Error Occured....")

    def saveUser(self,user):
        try:
            sql = "insert into users(name , email , username , password , description) values (%s , %s , %s , %s , %s )"
            values = (user.getName(),user.getEmail(),user.getUsername(),user.getPassword(),user.getDescription())
            self.__curr.execute(sql , values)
            self.__conn.commit()
            return self.__curr.rowcount
        except Exception as e:
            print(str(e))
            self.__conn.rollback()
        return 0        

    def loginUser(self , email , password):
        user = User()
        status = dict()
        try:
            self.__curr.execute("select * from users where email = '"+str(email)+"' and password = '"+str(password)+"'")
            result = self.__curr.fetchall()
            for res in result:
                user.setId(res[0])
            if self.__curr.rowcount > 0:
                status['result'] = 1
                status['data'] = user
            else:
                status['result'] = 0
                status['data'] = None
        except Exception as e:
            print(str(e))
            self.__conn.rollback()
        return status    