from models.DbConnection import DbConnection
from models.Forecast import Forecast
import mysql.connector

class ForecastModel:
    __conn = None 
    __curr = None 

    def __init__(self):
        try:
            self.__conn = DbConnection().getConn()
            self.__curr = self.__conn.cursor()
        except:
            print("Some Unexpected Error Occured....")

    def saveForecast(self,forecast):
        try:
            sql = "insert into forecast(temp , pressure , humidity , main , description , location) values (%s , %s , %s , %s , %s , %s )"
            values = (forecast.getTemp(),forecast.getPressure(),forecast.getHumidity(),forecast.getMain(),forecast.getDescription() , forecast.getLocation())
            self.__curr.execute(sql , values)
            self.__conn.commit()
            return self.__curr.rowcount
        except Exception as e:
            print(str(e))
            self.__conn.rollback()
        return 0        