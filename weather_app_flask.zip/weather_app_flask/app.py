from flask import Flask , render_template , request , session , flash , redirect , url_for
from models.UserModel import UserModel
from models.User import User
from models.ForecastModel import ForecastModel
from models.Forecast import Forecast
import geocoder 
from geopy.geocoders import Nominatim
import requests
import json

app = Flask(__name__)
app.secret_key = "weather app key"

geolocator = Nominatim(user_agent="geoapiExercises")
userModel = UserModel()
ForecastModel = ForecastModel()

@app.route("/" , methods = ["POST" , "GET"])
def index():
   if "user" not in session:
       flash("First You Have To Login....")
       return redirect(url_for("login"))
   url = "https://api.openweathermap.org/data/2.5/onecall?lat="+str(geocoder.ip('me').latlng[0])+"&lon="+str(geocoder.ip('me').latlng[1])+"&exclude=hourly,daily&appid=115905e1518d4cbadd33825716c36472"
   weather = requests.get(url)
   data = json.loads(weather.text)
   return render_template("index.html" , data=data)

@app.route("/login" , methods = ["POST" , "GET"])
def login():
    if request.method == "POST":
        email = request.form['email']
        password = request.form['password']
        loginStatus = userModel.loginUser(email , password)
        if loginStatus['result'] == 1:
            session["user"] = loginStatus['data'].getId()
            return redirect(url_for("index"))
        else:
            flash("Invalid Login Crediantials....")
            return redirect(url_for("login"))
    else:
        if "user" in session:
            return redirect(url_for("index"))
        else:
            return render_template("login.html")        

@app.route("/signup" , methods=["POST" , "GET"])
def signup():
    if request.method == "POST":
        user = User()
        user.setName(request.form['name'])
        user.setEmail(request.form['email'])
        user.setUsername(request.form['username'])
        user.setPassword(request.form['password'])
        user.setDescription(request.form['description'])
        result = userModel.saveUser(user)
        if result > 0:
            flash("You Have Signup Successfully...." , "info")
        else:
            flash("You Have Signup Not Successfully....", "info")
        return redirect(url_for("signup"))
    else:
        return render_template("signup.html")    

@app.route("/logout")
def logout():
    if "user" in session:
        flash("You Have Logout Successfully....")
    session.pop("user" , None)
    return redirect(url_for("login"))


if __name__ == '__main__':
   app.run(debug=True)